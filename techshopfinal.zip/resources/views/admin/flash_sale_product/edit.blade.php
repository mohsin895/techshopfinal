@extends('layout.admin.master')
@section('content')

<div class="content d-flex flex-column flex-column-fluid" id="kt_content">
    <!--begin::Toolbar-->
    <div class="toolbar" id="kt_toolbar">
        <!--begin::Container-->
        <div id="kt_toolbar_container" class="container-fluid d-flex flex-stack">
            <!--begin::Page title-->
            <div data-kt-swapper="true" data-kt-swapper-mode="prepend"
                data-kt-swapper-parent="{default: '#kt_content_container', 'lg': '#kt_toolbar_container'}"
                class="page-title d-flex align-items-center flex-wrap me-3 mb-5 mb-lg-0">
                <!--begin::Title-->
                <h1 class="d-flex text-dark fw-bolder fs-3 align-items-center my-1"><a
                        href="{{route('admin.dashboard')}}" class="hr"> {{$title}}</a></h1>
                <!--end::Title-->
                <!--begin::Separator-->
                <span class="h-20px border-gray-300 border-start mx-4"></span>
                <!--end::Separator-->
                <!--begin::Breadcrumb-->
                <ul class="breadcrumb breadcrumb-separatorless fw-bold fs-7 my-1">
                    <!--begin::Item-->
                    <li class="breadcrumb-item text-muted">
                        <a href="{{route('admin.flash_sale_product.index')}}" class="text-muted text-hover-primary">{{$table}}</a>
                    </li>
                    <li class="breadcrumb-item text-muted">
                        <a href="{{route('admin.flash_sale_product.add')}}" class="text-muted text-hover-primary">{{$add}}</a>
                    </li>

                    <!--end::Item-->
                </ul>
                <!--end::Breadcrumb-->
            </div>
            <!--end::Page title-->
            <!--begin::Actions-->

            <!--end::Actions-->
        </div>
        <!--end::Container-->
    </div>
    <!--end::Toolbar-->
    <!--begin::Post-->
    <div class="post d-flex flex-column-fluid" id="kt_post">
        <!--begin::Container-->
        <div id="kt_content_container" class="container-xxl">
            <!--begin::Form-->
          <form id="kt_ecommerce_add_product_form" method="post" class="form d-flex flex-column flex-lg-row"
                action="{{route('admin.flash_sale_product.update',$product->id)}}" enctype="multipart/form-data">
                @csrf
                <!--begin::Aside column-->
                <div class="d-flex flex-column gap-7 gap-lg-10 w-100 w-lg-300px mb-7 me-lg-10">
                    <!--begin::Thumbnail settings-->
                    <div class="card card-flush py-4">
                        <!--begin::Card header-->
                        <div class="card-header">
                            <!--begin::Card title-->
                            <div class="card-title">
                                <h2>Thumbnail</h2>
                            </div>
                            <!--end::Card title-->
                        </div>
                        <!--end::Card header-->
                        <!--begin::Card body-->
                        <div class="card-body text-center pt-0">
                            <!--begin::Image input-->
                            <div class="image-input image-input-empty image-input-outline mb-3"
                                data-kt-image-input="true"
                                style="background-image: url({{asset('public/assets/images/product/'.$product->image)}})">
                                <!--begin::Preview existing avatar-->
                                <div class="image-input-wrapper w-150px h-150px"></div>
                                <!--end::Preview existing avatar-->
                                <!--begin::Label-->
                                <label
                                    class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow"
                                    data-kt-image-input-action="change" data-bs-toggle="tooltip" title="Change avatar">
                                    <i class="bi bi-pencil-fill fs-7"></i>
                                    <!--begin::Inputs-->
                                    <input type="file" name="image" multiple="" accept=".png, .jpg, .jpeg" />
                                    <input type="hidden" name="avatar_remove" />
                                    <!--end::Inputs-->
                                </label>
                                <!--end::Label-->
                                <!--begin::Cancel-->
                                <span
                                    class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow"
                                    data-kt-image-input-action="cancel" data-bs-toggle="tooltip" title="Cancel avatar">
                                    <i class="bi bi-x fs-2"></i>
                                </span>
                                <!--end::Cancel-->
                                <!--begin::Remove-->
                                <span
                                    class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow"
                                    data-kt-image-input-action="remove" data-bs-toggle="tooltip" title="Remove avatar">
                                    <i class="bi bi-x fs-2"></i>
                                </span>
                                <!--end::Remove-->
                            </div>
                            <!--end::Image input-->
                            <!--begin::Description-->
                            <div class="text-muted fs-7">Set the product thumbnail image. Only *.png, *.jpg and *.jpeg
                                image files are accepted ,size:width:120px,height:150px.</div>
                            <!--end::Description-->
                        </div>


                        <!--end::Card body-->
                    </div>
                    <div class="card card-flush py-4">
                        <!--begin::Card header-->
                        <div class="card-header">
                            <!--begin::Card title-->
                            <div class="card-title">
                                <h2>Gallery</h2>
                            </div>
                            <!--end::Card title-->
                        </div>
                        <!--end::Card header-->
                        <!--begin::Card body-->
                        <div class="card-body text-center pt-0">
                            <!--begin::Image input-->
                            @php
                            $gallery = App\Models\Gallery::where('product_id',$product->id)->get();
                            $totalQuantity = App\Models\Qty::where('product_id',$product->id)->sum('quantity');
                            
                            @endphp
                            @foreach($gallery as $image)
                            <div class="image-input image-input-empty image-input-outline mb-3"
                                data-kt-image-input="true"
                                style="background-image: url({{asset('public/assets/images/product/gallery/'.$image->galery)}})">
                                <!--begin::Preview existing avatar-->
                                <div class="image-input-wrapper w-150px h-150px"></div>
                                <!--end::Preview existing avatar-->
                                <!--begin::Label-->
                                <label
                                    class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow"
                                    data-kt-image-input-action="change" data-bs-toggle="tooltip" title="Change avatar">
                                    <i class="bi bi-pencil-fill fs-7"></i>
                                    <!--begin::Inputs-->
                                    <input type="file" name="gallery[]" accept=".png, .jpg, .jpeg" />
                                    <input type="hidden" name="avatar_remove" />
                                    <!--end::Inputs-->
                                </label>
                                <!--end::Label-->
                                <!--begin::Cancel-->
                                <span
                                    class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow"
                                    data-kt-image-input-action="cancel" data-bs-toggle="tooltip" title="Cancel avatar">
                                    <i class="bi bi-x fs-2"></i>
                                </span>
                                <!--end::Cancel-->
                                <!--begin::Remove-->
                                <span
                                    class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow"
                                    data-kt-image-input-action="remove" data-bs-toggle="tooltip" title="Remove avatar">
                                    <i class="bi bi-x fs-2"></i>
                                </span>
                                <!--end::Remove-->
                            </div>
                            @endforeach
                           


                            <!--end::Image input-->
                            <!--begin::Description-->
                            <div class="text-muted fs-7">Set the product thumbnail image. Only *.png, *.jpg and *.jpeg
                                image files are accepted</div>
                            <!--end::Description-->
                        </div>


                        <!--end::Card body-->
                    </div>
                    <!--end::Thumbnail settings-->
                    <!--begin::Status-->


                </div>
                <!--end::Aside column-->
                <!--begin::Main column-->
                <div class="d-flex flex-column flex-row-fluid gap-7 gap-lg-10">
                    <!--begin:::Tabs-->

                    <!--end:::Tabs-->
                    <!--begin::Tab content-->
                    <div class="tab-content">
                        <!--begin::Tab pane-->
                        <div class="tab-pane fade show active" id="kt_ecommerce_add_product_general" role="tab-panel">
                            <div class="d-flex flex-column gap-7 gap-lg-10">
                                <!--begin::General options-->
                                <div class="card card-flush py-4">
                                    <!--begin::Card header-->

                                    <!--end::Card header-->
                                    <!--begin::Card body-->
                                    <div class="card-body pt-0">

                                        <div class="mb-10 fv-row">
                                            <!--begin::Input group-->
                                            <!--begin::Label-->
                                            <label class="form-label">Categories</label>
                                            <!--end::Label-->
                                            <!--begin::Select2-->
                                            <select class="form-select mb-2" name="parent_id" id="parent_id"
                                                data-control="select2" data-placeholder="Select an option"
                                                data-allow-clear="true" required>
                                                <option></option>
                                                 @foreach($category as $row)
                                                <option value="{{$row->id}}" @if($row->id==$product->parent_id) ? selected @endif;>{{$row->cat_name}}</option>
                                                @endforeach
                                            </select>
                                            <!--end::Select2-->
                                            <!--begin::Description-->

                                        </div>

                                        <div class="mb-10 fv-row">
                                            <!--begin::Input group-->
                                            <!--begin::Label-->
                                            <label class="form-label">Sub Categories</label>
                                            <!--end::Label-->
                                            <!--begin::Select2-->
                                            <select class="form-select mb-2" name="subcat_id" id="subcat_id"
                                                data-control="select2" data-placeholder="Select a Sub Category"
                                                data-allow-clear="true" required>
                                                @foreach($subcategory as $row)
                                                <option value="{{$row->id}}" disabled @if($row->id==$product->subcat_id) ? selected @endif; >{{$row->cat_name}}</option>
                                                @endforeach

                                            </select>
                                            <!--end::Select2-->
                                            <!--begin::Description-->

                                        </div>
                                        <!--begin::Input group-->
                                        <div class="mb-10 fv-row">
                                            <!--begin::Label-->
                                            <label class="required form-label">Product Name</label>
                                            <!--end::Label-->
                                            <!--begin::Input-->
                                            <input type="text" name="product_name" class="form-control mb-2"
                                                placeholder="Product name" value="{{$product->product_name}}" />
                                            <!--end::Input-->
                                            <!--begin::Description-->

                                        </div>
                                        <div class="mb-10 fv-row">
                                            <!--begin::Label-->
                                            <label class="required form-label">Buying Price</label>
                                            <!--end::Label-->
                                            <!--begin::Input-->
                                            <input type="text" name="buying_price" class="form-control mb-2"
                                                placeholder="Enter Buying Price" value="{{$product->buying_price}}" />
                                            <!--end::Input-->
                                            <!--begin::Description-->

                                        </div>

                                        <div class="mb-10 fv-row">
                                            <!--begin::Label-->
                                            <label class="required form-label">Selling Price</label>
                                            <!--end::Label-->
                                            <!--begin::Input-->
                                            <input type="text" name="price" class="form-control mb-2"
                                                placeholder="Enter Selling Price" value="{{$product->price}}" />
                                            <!--end::Input-->
                                            <!--begin::Description-->

                                        </div>

                                        <div class="mb-10 fv-row">
                                            <!--begin::Label-->
                                            <label class="required form-label">Flase Sale Price</label>
                                            <!--end::Label-->
                                            <!--begin::Input-->
                                            <input type="text" name="flash_sale_price" class="form-control mb-2"
                                                placeholder="EnterFlash  Selling Price" value="{{$product->flash_sale_price}}" required />
                                            <!--end::Input-->
                                            <!--begin::Description-->

                                        </div>
                                        <div class="mb-10 fv-row">
                                            <!--begin::Label-->
                                            <label class="required form-label">Flase Sale Start Date</label>
                                            <!--end::Label-->
                                            <!--begin::Input-->
                                            <input type="date" name="flash_sale_start_date" class="form-control mb-2"
                                                placeholder="EnterFlash  Selling Price" value="{{$product->flash_sale_start_date}}" required />
                                            <!--end::Input-->
                                            <!--begin::Description-->

                                        </div>
                                        <div class="mb-10 fv-row">
                                            <!--begin::Label-->
                                            <label class="required form-label">Flase Sale End Date</label>
                                            <!--end::Label-->
                                            <!--begin::Input-->
                                            <input type="date" name="flash_sale_end_date" class="form-control mb-2"
                                                placeholder="EnterFlash  Selling Price" value="{{$product->flash_sale_end_date}}" required/>
                                            <!--end::Input-->
                                            <!--begin::Description-->

                                        </div>
                                        <div class="mb-10 fv-row">
                                            <!--begin::Input group-->
                                            <!--begin::Label-->
                                            <label class="form-label">Flash Sale</label>
                                            <!--end::Label-->
                                            <!--begin::Select2-->
                                            <select class="form-select mb-2" name="flash_sale" 
                                                data-control="select2" data-placeholder="Select an option"
                                                data-allow-clear="true" required>
                                                
                                                <option value="1" @if($product->flash_sale== '1') selected="" @endif>Yes</option>
                                                <option value="0" @if($product->flash_sale== '0') selected="" @endif>No</option>
                                               
                                            </select>
                                            <!--end::Select2-->
                                            <!--begin::Description-->

                                        </div>


                                        <div class="mb-10 fv-row">
                                            <!--begin::Label-->
                                            <label class="required form-label">Stock Quantity</label>
                                            <!--end::Label-->
                                            <!--begin::Input-->
                                            <input type="number" name="quantity" class="form-control mb-2"
                                                placeholder="Quantity" value="{{$totalQuantity}}" min="1" />
                                            <!--end::Input-->
                                            <!--begin::Description-->

                                        </div>
                                        <div class="mb-10 fv-row">
                                            <!--begin::Label-->
                                            <label class="required form-label">Product Model</label>
                                            <!--end::Label-->
                                            <!--begin::Input-->
                                            <input type="text" name="model_no" class="form-control mb-2"
                                                placeholder="Product name" value="{{$product->model_no}}"/>
                                            <!--end::Input-->
                                            <!--begin::Description-->

                                        </div>
                                        <div class="mb-10 fv-row">
                                            <!--begin::Label-->
                                            <label class="required form-label">Product Supplier</label>
                                            <!--end::Label-->
                                            <!--begin::Input-->
                                            <input type="text" name="supplier" class="form-control mb-2"
                                                placeholder="Product name" value="{{$product->supplier}}" >
                                            <!--end::Input-->
                                            <!--begin::Description-->

                                        </div>
                                        <!--end::Input group-->
                                        <!--begin::Input group-->
                                
                                        <div>

                                            <label class="form-label">Summery</label>

                                            <div class="">
                                                <textarea name="summery" rows="4" cols="100" class="ckeditor">{{$product->summery}}</textarea>


                                            </div>

                                        </div>
                                        <div>

                                            <label class="form-label">Document</label>

                                            <div class="">
                                                <textarea name="document" rows="4" cols="100" class="ckeditor">{{$product->document}}</textarea>


                                            </div>

                                        </div>
                                      
                                        <!--end::Input group-->
                                    </div>
                                    <!--end::Card header-->
                                </div>
                                <!--end::General options-->
                                <!--begin::Media-->

                                <!--end::Media-->
                                <!--begin::Pricing-->

                                <!--end::Pricing-->
                            </div>
                        </div>

                    </div>
                    <!--end::Tab content-->
                    <div class="d-flex justify-content-end">
                        <!--begin::Button-->
                        <a href="#"
                            id="kt_ecommerce_add_product_cancel" class="btn btn-light me-5">Cancel</a>
                        <!--end::Button-->
                        <!--begin::Button-->
                        <button type="submit" class="btn btn-primary">
                            <span class="indicator-label">Save Changes</span>

                        </button>
                        <!--end::Button-->
                    </div>
                </div>
                <!--end::Main column-->
            </form>
            <!--end::Form-->
        </div>
        <!--end::Container-->
    </div>
    <!--end::Post-->
</div>

<script type="text/javascript">
$(function() {
    $(document).on('change', '#parent_id', function() {

        var parent_id = $(this).val();

        $.ajax({
            url: "{{route('admin.get_subcategory')}}",
            type: "GET",
            data: {
                parent_id: parent_id
            },
            success: function(data) {
                var html = '<option value="">Select SubCategory</option>';
                $.each(data, function(key, v) {
                    html += '<option value ="' + v.id + '"  data-name="' + v
                        .cat_name + '">' + v.cat_name + '</option>';
                });
                $('#subcat_id').html(html);
            }
        });
    });
});
</script>
<script>
ClassicEditor
    .create(document.querySelector('#kt_docs_ckeditor_classic'))
    .then(editor => {
        console.log(editor);
    })
    .catch(error => {
        console.error(error);
    });
</script>
<script type="text/javascript">
$(document).ready(function() {
    $('.summernote').summernote();
});
</script>
@endsection