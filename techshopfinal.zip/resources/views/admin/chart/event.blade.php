@extends('layout.admin.master')
@section('content')
<div class="content d-flex flex-column flex-column-fluid" id="kt_content">
    <!--begin::Toolbar-->
    <div class="toolbar" id="kt_toolbar">
        <!--begin::Container-->
        <div id="kt_toolbar_container" class="container-fluid d-flex flex-stack">
            <!--begin::Page title-->
            <div data-kt-swapper="true" data-kt-swapper-mode="prepend"
                data-kt-swapper-parent="{default: '#kt_content_container', 'lg': '#kt_toolbar_container'}"
                class="page-title d-flex align-items-center flex-wrap me-3 mb-5 mb-lg-0">
                <!--begin::Title-->
                <h1 class="d-flex text-dark fw-bolder fs-3 align-items-center my-1"><a
                        href="{{route('admin.dashboard')}}" class="hr"> {{$title}}</a></h1>
                <!--end::Title-->
                <!--begin::Separator-->
                <span class="h-20px border-gray-300 border-start mx-4"></span>
                <!--end::Separator-->
                <!--begin::Breadcrumb-->
                <ul class="breadcrumb breadcrumb-separatorless fw-bold fs-7 my-1">
                    <!--begin::Item-->
                    <li class="breadcrumb-item text-muted">
                        <a href="#" class="text-muted text-hover-primary">{{$table}}</a>
                    </li>

                    <!--end::Item-->
                </ul>
                <!--end::Breadcrumb-->
            </div>
            <!--end::Page title-->
            <!--begin::Actions-->

            <!--end::Actions-->
        </div>
        <!--end::Container-->
    </div>
    <!--end::Toolbar-->
    <!--begin::Post-->
    <div class="post d-flex flex-column-fluid" id="kt_post">
        <!--begin::Container-->
        <div id="kt_content_container" class="container-xxl">
            @include('error.message')
            <!--begin::Category-->
            <div class="card card-flush">
                <!--begin::Card header-->
                <table class="table table-dark table-borderless">
                    <thead>
                        <tr>
                            <th scope="col" style="font-size:30px">Average Order Per Customer</th>
                            <th scope="col" style="font-size:30px"><?=$customer ? $order/$customer : 0 ?></th>

                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <th scope="row" style="font-size:30px">Total Customer</th>
                            <td style="font-size:30px">{{$customer}}</td>

                        </tr>
                        <tr>
                            <th scope="row" style="font-size:30px">Total Order</th>
                            <td style="font-size:30px">{{$order}}</td>
                        </tr>
                        <tr>
                            <th scope="row" style="font-size:30px">Total Active User(last Two Month)</th>
                            <td colspan="2" style="font-size:30px">{{$last_two_month_login}}</td>

                        </tr>
                        <tr>
                            <th scope="row" style="font-size:30px">Total InActive User(More Then last Two Month)</th>
                            <td colspan="2" style="font-size:30px">{{$last_two_month_inactive}}</td>

                        </tr>
                    </tbody>
                </table>



                <!--end::Card header-->
                <!--begin::Card body-->

                <form method="get" route="?">

                    <table class="table table-borderless">
                        <thead>
                            <tr>
                                <th scope="col"><button value="" class=" btn btn-secondary form-control">Period
                                        From </button></th>
                                <th scope="col"><button value="" class=" btn btn-secondary form-control">To</button>
                                <th scope="col"><a href="{{route('admin.event.chart')}}"
                                        class=" btn btn-secondary form-control">Reset</a>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <th> <input type="date" class="form-control" name="from"
                                        value="{{ request()->input('from') }}" /> </th>
                                <td><input type="date" class="form-control" name="to"
                                        value="{{ request()->input('to') }}" /></td>

                                <td><button value="" class=" btn btn-secondary form-control">Search</button></td>


                            </tr>

                        </tbody>
                    </table>


                </form>

             

                <?php $total_amount = 0; ?>
                <?php $total_qty = 0; ?>
                <?php $total_revenue = 0; ?>
                @if(!empty($order_product))
                <!--begin::Table row-->
                @foreach($order_product as $row)
                @php
                $product= App\Models\Product::find($row->product_id);
                $productqty = App\Models\OrderProduct::where('product_id',$product->id)->sum('quantity');

                @endphp

                <?php $total_amount =  $total_amount + (($product->price*$productqty) - ($product->buying_price*$productqty)); ?>
                <?php $total_qty =  $total_qty + $productqty; ?>
                
                <?php $total_revenue =  $total_revenue + (($product->price*$productqty)); ?>
                @endforeach
                @else

                @endif

                <?php $total_event_cost = 0; ?>

                @if(!empty($event))
                            <!--begin::Table row-->
                            @foreach($event as $row)

                           
                            <?php $total_event_cost =  $total_event_cost + ($row->event_cost); ?>

                            @endforeach
                            @else

                            @endif
                <div class="card-body pt-0">

                <table class="table align-middle table-row-dashed fs-6 gy-5">
                        <!--begin::Table head-->
                        <thead>
                            <!--begin::Table row-->
                            <tr class="text-start text-gray-400 fw-bolder fs-7 text-uppercase gs-0">

                                <th class="min-w-70px">Event Name</th>
                                <th class="min-w-70px">Event Date</th>
                                <th class="min-w-70px">Event Cost</th>

                            </tr>
                            <!--end::Table row-->
                        </thead>
                        <!--end::Table head-->
                        <!--begin::Table body-->

                        <tbody class="fw-bold text-gray-600">
                            @if(!empty($event))
                            <!--begin::Table row-->
                            @foreach($event as $row)

                            <tr>

                                <td>


                                    {{ $row->event_name}}

                                </td>

                                <td>{{ $row->event_date}}</td>

                                <td>{{$gs->currency}}&nbsp;&nbsp;{{$row->event_cost}}</td>

                            </tr>


                            @endforeach
                            @else

                            @endif
                            <!--end::Table row-->
                        </tbody>

                        <!--end::Table body-->
                    </table>
<hr>
                    <table class="table align-middle table-row-dashed fs-6 gy-5">
                        <!--begin::Table head-->
                        <thead>
                            <!--begin::Table row-->
                            <tr class="text-start text-gray-400 fw-bolder fs-7 text-uppercase gs-0">

                                <th class="min-w-70px">Total Revenue</th>
                                <th class="min-w-70px">{{$gs->currency}}&nbsp;&nbsp;<?php echo $total_revenue; ?></th>


                            </tr>
                            <!--end::Table row-->
                        </thead>
                        <!--end::Table head-->
                        <!--begin::Table body-->

                        <tbody class="fw-bold text-gray-600">


                            <tr>
                                <td>
                                Total Profit
                                </td>

                                <td>{{$gs->currency}}&nbsp;&nbsp;<?php echo $total_amount - $total_event_cost; ?></td>

                            </tr>

                            <tr>
                                <td>
                                Total Product Sale(Qty)
                                </td>

                                <td><?php echo $total_qty; ?></td>

                            </tr>



                            <!--end::Table row-->
                        </tbody>

                        <!--end::Table body-->
                    </table>
                    <!--begin::Table-->
                   
                    <!--end::Table-->
                </div>

<hr>
                <div class="card-body pt-0">

                    <!--begin::Table-->
                    <table class="table align-middle table-row-dashed fs-6 gy-5" id="kt_ecommerce_category_table">
                        <!--begin::Table head-->
                        <thead>
                            <!--begin::Table row-->
                            <tr class="text-start text-gray-400 fw-bolder fs-7 text-uppercase gs-0">

                                <th class="min-w-70px">Product Name</th>
                                <th class="min-w-70px">Buying Price</th>
                                <th class="min-w-70px">Selling Price</th>
                                <th class="min-w-70px">Product Qty</th>

                            </tr>
                            <!--end::Table row-->
                        </thead>
                        <!--end::Table head-->
                        <!--begin::Table body-->

                        <tbody class="fw-bold text-gray-600">
                            @if(!empty($order_product))
                            <!--begin::Table row-->
                            @foreach($order_product as $row)
                            @php
                            $product= App\Models\OrderProduct::find($row->product_id);
                            $productqty =
                            App\Models\OrderProduct::where('product_id',$product->id)->sum('quantity');

                            @endphp
                            <tr>

                                <td>


                                    {{ $product->product_name}}

                                </td>
                                <td>{{$gs->currency}}&nbsp;&nbsp;{{ $product->buying_price}}</td>

                                <td>{{$gs->currency}}&nbsp;&nbsp;{{ $product->price}}</td>

                                <td>{{$productqty}}</td>
                                <!--end::Category=-->
                                <!--begin::Type=-->
                                <!-- <td>
                                   
                                    <div class=""><input type="checkbox" {{$row->status=='1'? 'checked':''}}
                                            id="categoryStatus" data-id="{{$row->id}}" data-toggle="toggle"
                                            data-on="Enabled" data-off="Disabled"></div>
                                   
                                </td> -->
                                <!--end::Type=-->
                                <!--begin::Action=-->

                                <!--end::Action=-->
                            </tr>
                            <!--end::Table row-->

                            @endforeach
                            @else

                            @endif
                            <!--end::Table row-->
                        </tbody>

                        <!--end::Table body-->
                    </table>
                    <!--end::Table-->
                </div>
                <!--end::Card body-->
            </div>
            <!--end::Category-->
        </div>
        <!--end::Container-->
    </div>
    <!--end::Post-->
</div>

@endsection