<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>{{$subject}}</title>
  </head>
  <body>
    <table>
      <tr>
    
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>
            {{$body }}
        </td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
    
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>Thanks & Regrads</td>
      </tr>
      <tr>
        <td>{{$gs->website_name}}</td>
      </tr>
    </table>
  </body>
</html>
