<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>{{$subject}}</title>
  </head>
  <body>
    <table>
      <tr>
      <td>  Dear {{$name}}</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
       
     
      
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>Email: {{$email}}</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
      <td>Your Question::{{$body}}</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>Your Answer::{{$answer}}</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>Thanks & Regrads</td>
      </tr>
      <tr>
        <td>{{$gs->site_title}}</td>
      </tr>
    </table>
  </body>
</html>
